# space_titanic_kaggle
Code for my youtube video on a practical introduction to Data Science with the space-titanic dataset: https://studio.youtube.com/video/HReBjpi9dCY/edit
